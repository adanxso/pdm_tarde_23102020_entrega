class Contact {
  constructor({ id, name, phone, image, location, createAt }) {
    this.id = id
    this.name = name
    this.phone = phone
    this.image = image
    this.location = location
    this.createAt = createAt
  }
}

export default Contact
