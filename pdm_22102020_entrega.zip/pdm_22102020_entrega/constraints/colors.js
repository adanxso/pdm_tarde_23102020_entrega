export default {
  primary: '#2196F3'
}
